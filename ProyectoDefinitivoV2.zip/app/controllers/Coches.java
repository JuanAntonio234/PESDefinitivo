    package controllers;

import play.*;
import play.mvc.*;
import play.data.validation.*;
import java.util.*;

import models.*;

public class Coches extends Controller{
   
    public static void list(){
        render();
    }
    
}
